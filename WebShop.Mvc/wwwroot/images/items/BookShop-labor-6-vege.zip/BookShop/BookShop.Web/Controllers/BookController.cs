﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookShop.Dal.Entities;
using BookShop.Dal.Services;
using BookShop.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace BookShop.Web.Controllers
{
    [Authorize]
    public class BookController : Controller
    {
        public BookService BookService { get; }
        public CommentService CommentService { get; }
        public UserManager<User> UserManager { get; }

        public BookController( BookService bookService, CommentService commentService, UserManager<User> userManager)
        {
            BookService = bookService;
            CommentService = commentService;
            UserManager = userManager;
        }

        private int? currentUserId;
        public int? CurrentUserId => User.Identity.IsAuthenticated
            ? (currentUserId ?? (currentUserId = int.Parse( UserManager.GetUserId( User ) )))
            : null;

        [AllowAnonymous]
        public IActionResult Index( int? id )
        {
            if (!id.HasValue)
                return RedirectToAction("Index", "Home");

            var book = BookService.GetBook(id.Value);

            if (book == null)
                return NotFound();

            var comments = CommentService.GetComments(id.Value);

            var model = new BookModel
            {
                Book = book,
                Comments = comments,
                CurrentUserId = CurrentUserId
            };

            return View( model );
        }

        [HttpPost]
        public ActionResult AddComment( int bookId, string text )
        {
            CommentService.PostComment(bookId, text, CurrentUserId.Value);

            return RedirectToAction("Index", "Book", new { id = bookId });
        }
    }
}