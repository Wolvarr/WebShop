﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookShop.Dal.Dto;
using Microsoft.AspNetCore.Mvc;

namespace BookShop.Web.Views.Shared.Components
{
    public class BooksListViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke (PagedResult<BookHeader> books)
        {
            return View(books);
        }
    }
}
