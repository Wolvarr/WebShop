﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookShop.Dal.Services;
using Microsoft.AspNetCore.Mvc;

namespace BookShop.Web.Views.Shared.Components
{
    public class CategoryListViewComponent : ViewComponent
    {
        public CategoryListViewComponent(CategoryService categoryService)
        {
            CategoryService = categoryService;
        }

        public CategoryService CategoryService { get; }

        public IViewComponentResult Invoke()
        {
            return View(CategoryService.GetCategoryTree());
        }
    }

}
