﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookShop.Dal.Dto;
using Microsoft.AspNetCore.Mvc;

namespace BookShop.Web.Views.Shared.Components
{
    public class BookHeaderViewComponent: ViewComponent
    {
        public IViewComponentResult Invoke(BookHeader bookHeader)
        {
            return View(bookHeader);
        }
    }
}
