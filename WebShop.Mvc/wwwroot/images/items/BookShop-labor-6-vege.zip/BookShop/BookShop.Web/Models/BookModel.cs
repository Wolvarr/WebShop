﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookShop.Dal.Dto;

namespace BookShop.Web.Models
{
    public class BookModel
    {
        public BookHeader Book { get; set; }
        public IEnumerable<CommentHeader> Comments { get; set; }
        public int? CurrentUserId { get; set; }
    }
}
