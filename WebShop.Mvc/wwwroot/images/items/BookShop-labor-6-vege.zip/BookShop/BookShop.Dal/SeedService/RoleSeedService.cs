﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BookShop.Dal.SeedInterfaces;
using BookShop.Dal.Users;
using Microsoft.AspNetCore.Identity;

namespace BookShop.Dal.SeedService
{
    public class RoleSeedService : IRoleSeedService
    {
        private readonly RoleManager<IdentityRole<int>> _roleManager;

        public RoleSeedService( RoleManager<IdentityRole<int>> roleManager )
        {
            _roleManager = roleManager;
        }

        public async Task SeedRoleAsync()
        {
            if (!await _roleManager.RoleExistsAsync(Roles.Administrators))
                await _roleManager.CreateAsync(new IdentityRole<int> { Name = Roles.Administrators });
        }
    }
}
