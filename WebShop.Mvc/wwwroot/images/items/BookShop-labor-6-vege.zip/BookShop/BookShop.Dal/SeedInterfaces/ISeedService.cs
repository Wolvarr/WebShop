﻿using BookShop.Dal.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Dal.SeedInterfaces
{
    public interface ISeedService
    {
        IDictionary<string, Author> Authors { get; }
        IDictionary<string, Category> Categories { get; }
        IDictionary<string, Publisher> Publishers { get; }
        IList<Book> Books { get; }
    }
}
