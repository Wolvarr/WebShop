﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BookShop.Dal.Dto;
using BookShop.Dal.Entities;

namespace BookShop.Dal.Services
{
	public class CategoryService
	{
		public CategoryService(BookShopDbContext dbContext)
		{
			DbContext = dbContext;
		}

		private BookShopDbContext DbContext { get; }

		public IEnumerable<CategoryDto> GetCategoryTree()
		{
			var allCategories = DbContext.Categories.ToList();
			var categories = new Stack<(Category category, int level)>
					(allCategories.OrderByDescending(c => c.Order)
					.Where(c => c.ParentCategory == null).Select(c => (c, 0)));
			while (categories.TryPop(out var elem))
			{
				yield return new CategoryDto
				{
					Id = elem.category.Id,
					Level = elem.level,
					Name = elem.category.Name
				};

				foreach (var child in elem.category.ChildCategories?.OrderByDescending(c => c.Order)
							?? Enumerable.Empty<Category>())
					categories.Push((child, elem.level + 1));
			}
		}
	}

}
