﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using BookShop.Dal.Dto;
using BookShop.Dal.Entities;

namespace BookShop.Dal.Services
{
    public class CommentService
    {
        public BookShopDbContext DbContext { get; }

        public CommentService(BookShopDbContext dbContext)
        {
            DbContext = dbContext;
        }

        public static Expression<Func<Comment, CommentHeader>> CommentHeaderSelector { get; } = c => new CommentHeader
        {
            Id = c.Id,
            BookId = c.BookId,
            CreationDate = c.CreationDate,
            Text = c.Text,
            User = c.User.Name ?? c.User.UserName,
            UserId = c.UserId
        };

        /// <summary>
        /// Könyvhoz tartozó commentek lekérdezése.
        /// </summary>
        /// <param name="id">Könyv egyedi azonosítója.</param>
        /// <returns></returns>
        public IEnumerable<CommentHeader> GetComments( int id)
        {
            return DbContext.Comments
                .Where(c => c.BookId == id)
                .OrderByDescending(c => c.Id)
                .Select( CommentHeaderSelector )
                .AsEnumerable();
        }

        /// <summary>
        /// Új comment hozzáadása
        /// </summary>
        /// <param name="bookId"></param>
        /// <param name="text"></param>
        /// <param name="currentUserId"></param>
        /// <returns></returns>
        public CommentHeader PostComment( int bookId, string text, int currentUserId)
        {
            var comment = DbContext.Comments.Add(new Comment
            {
                BookId = bookId,
                CreationDate = DateTimeOffset.Now,
                Text = text,
                UserId = currentUserId
            });

            DbContext.SaveChanges();

            return DbContext.Comments
                .Where(c => c.Id == comment.Entity.Id)
                .Select(CommentHeaderSelector)
                .Single();
        }

        /// <summary>
        /// Komment törlése
        /// </summary>
        /// <param name="commentId"></param>
        /// <param name="currentUserId"></param>
        /// <returns></returns>
        public CommentHeader DeleteComment( int commentId, int currentUserId)
        {
            var comment = DbContext.Comments
                .Where(c => c.Id == commentId && c.UserId == currentUserId)
                .Select(CommentHeaderSelector)
                .Single();

            DbContext.Remove(new Comment { Id = commentId });
            DbContext.SaveChanges();

            return comment;
        }
    }
}
