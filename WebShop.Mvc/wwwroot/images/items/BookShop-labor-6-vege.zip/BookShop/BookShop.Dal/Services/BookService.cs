﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using BookShop.Dal.Dto;
using BookShop.Dal.Entities;
using BookShop.Dal.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BookShop.Dal.Services
{
    public class BookService
    {
        public static Expression<Func<Book, BookHeader>> BookHeaderSelector { get; } = b => new BookHeader
        {
            Author = b.Author != null ? b.Author.Name : String.Empty,
            AuthorId = b.AuthorId,
            //AverageRating = b.Ratings.Select(r => (double?)r.Value).DefaultIfEmpty(null).Average(),
            AverageRating = b.Ratings.Any() ? b.Ratings.Select(r => (double)r.Value).Average() : 0,
            CategoryId = b.CategoryId,
            DiscountedPrice = b.DiscountedPrice,
            Id = b.Id,
            NumberOfComments = b.Comments.Count(),
            NumberOfPages = b.NumberOfPages,
            NumberOfRatings = b.Ratings.Count(),
            Price = b.Price,
            Publisher = b.Publisher != null ? b.Publisher.Name : String.Empty,
            PublisherId = b.PublisherId,
            PublishYear = b.PublishYear,
            ShortDescription = b.ShortDescription,
            Headline = b.Headline,
            Title = b.Title
        };

        public static Lazy<Func<Book, BookHeader>> BookHeaderSelectorFunc { get; } = new Lazy<Func<Book, BookHeader>>(() => BookHeaderSelector.Compile());

        public BookShopDbContext DbContext { get; }

        public BookService(BookShopDbContext dbContext)
        {
            DbContext = dbContext;
        }

        public PagedResult<BookHeader> GetBooks (BooksSpecification specification = null)
        {
            // Validáció
            if (specification == null)
                specification = new BooksSpecification();

            if (specification.PageSize < 0)
                specification.PageSize = null;
            if (specification.PageNumber < 0)
                specification.PageNumber = null;

            // Alap lekérdezés
            IQueryable<Book> query = DbContext.Books
                .Include(b => b.Author)
                .Include(b => b.Ratings)
                .Include(b => b.Comments)
                .Include(b => b.Publisher)
                .Include(b => b.Category).ThenInclude( c => c.ParentCategory );

            // Szűrés
            if (!string.IsNullOrWhiteSpace(specification.Author))
                query = query.Where(b => b.Author.Name.Contains(specification.Author));

            if (specification.AuthorId.HasValue )
                query = query.Where(b => b.AuthorId == specification.AuthorId);

            if (!string.IsNullOrWhiteSpace(specification.Category))
                query = query.Where(b => b.Category.Name.Contains(specification.Category) || b.Category.ParentCategory.Name.Contains( specification.Category) );

            if (specification.CategoryId.HasValue)
                query = query.Where(b => b.CategoryId == specification.CategoryId || b.Category.ParentCategoryId == specification.CategoryId );

            if (specification.MinRating.HasValue)
                query = query.Where(b => b.Ratings.Select(r => r.Value).DefaultIfEmpty(0).Average() >= specification.MinRating);

            if (!string.IsNullOrWhiteSpace(specification.Publisher))
                query = query.Where(b => b.Publisher.Name.Contains(specification.Publisher));

            if (specification.PublisherId.HasValue)
                query = query.Where(b => b.PublisherId == specification.PublisherId);

            if (!string.IsNullOrWhiteSpace(specification.Title))
                query = query.Where(b => b.Title.Contains(specification.Title) || b.Headline.Contains(specification.Title));

            if (specification.MinPrice != null)
                query = query.Where(b => (b.DiscountedPrice ?? b.Price) >= specification.MinPrice);

            if (specification.MaxPrice != null)
                query = query.Where(b => (b.DiscountedPrice ?? b.Price) <= specification.MaxPrice);

            if (specification.MinPublishYear != null)
                query = query.Where(b => b.PublishYear >= specification.MinPublishYear);

            if (specification.MaxPublishYear != null)
                query = query.Where(b => b.PublishYear <= specification.MaxPublishYear);

            // Rendezés
            switch (specification.Order)
            {
                case BooksSpecification.BookOrder.TitleAscending:
                    query = query.OrderBy(b => b.Title);
                    break;
                case BooksSpecification.BookOrder.TitleDescending:
                    query = query.OrderByDescending(b => b.Title);
                    break;
                case BooksSpecification.BookOrder.PublishYearDescending:
                    query = query.OrderByDescending(b => b.PublishYear);
                    break;
                case BooksSpecification.BookOrder.PriceAscending:
                    query = query.OrderBy(b => b.DiscountedPrice ?? b.Price);
                    break;
                case BooksSpecification.BookOrder.PriceDescending:
                    query = query.OrderByDescending(b => b.DiscountedPrice ?? b.Price);
                    break;
                case BooksSpecification.BookOrder.RatingDescending:
                    query = query.OrderByDescending(b => b.Ratings.Average(r => r.Value));
                    break;
            }

            int? allResultsCount = null;
            if( (specification.PageSize ?? 0) != 0)
            {
                specification.PageNumber ??= 0;
                allResultsCount = query.Count();
                query = query
                    .Skip( specification.PageNumber.Value * specification.PageSize.Value )      // PageNumber 0-tól indul.
                    .Take( specification.PageSize.Value );
            }

            return new PagedResult<BookHeader>
            {
                AllResultsCount = allResultsCount,
                Results = query.ToList().Select(BookHeaderSelectorFunc.Value),
                PageNumber = specification.PageNumber,
                PageSize = specification.PageSize
            };
        }

        public BookHeader GetBook( int id )
        {
            return DbContext.Books.Where(b => b.Id == id).Select(BookHeaderSelector).SingleOrDefault();
        }

        public IEnumerable<BookHeader> GetAllBooks()
        {
            return DbContext.Books
                .Include( b => b.Author )
                .Include(b => b.Ratings)
                .Include(b => b.Comments)
                .Include(b => b.Publisher)
                .Select(b => new BookHeader
                {
                    Author = b.Author.Name,
                    AuthorId = b.AuthorId,
                    AverageRating = b.Ratings.Select(r => (double)r.Value).Average(),
                    CategoryId = b.CategoryId,
                    DiscountedPrice = b.DiscountedPrice,
                    Id = b.Id,
                    NumberOfComments = b.Comments.Count(),
                    NumberOfPages = b.NumberOfPages,
                    NumberOfRatings = b.Ratings.Count(),
                    Price = b.Price,
                    Publisher = b.Publisher.Name,
                    PublisherId = b.PublisherId,
                    PublishYear = b.PublishYear,
                    ShortDescription = b.ShortDescription,
                    Headline = b.Headline,
                    Title = b.Title
                }).ToList();
        }
    }
}
