﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Dal.Specifications
{
    public class BooksSpecification
    {
        /// <summary>
        /// Melyik oldalon vagyunk.
        /// </summary>
        public int? PageNumber { get; set; }
        /// <summary>
        /// Mekkor az oldalméret.
        /// </summary>
        public int? PageSize { get; set; } = 24;

        // Keresési feltételek
        public string Title { get; set; }
        public string Author { get; set; }
        public int? AuthorId { get; set; }
        public string Publisher { get; set; }
        public int? PublisherId { get; set; }
        public string Category { get; set; }
        public int? CategoryId { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public int? MinPublishYear { get; set; }
        public int? MaxPublishYear { get; set; }
        public double? MinRating { get; set; }

        public BookOrder? Order { get; set; }

        public enum BookOrder
        {
            TitleAscending,
            TitleDescending,
            PublishYearDescending,
            PriceAscending,
            PriceDescending,
            RatingDescending
        }
    }
}
