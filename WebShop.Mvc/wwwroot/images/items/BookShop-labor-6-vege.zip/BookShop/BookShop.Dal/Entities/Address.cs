﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Dal.Entities
{
    public class Address
    {
        public string ZipCode { get; set; }
        public string Settlement { get; set; }
        public string StreetAddress { get; set; }
    }
}
