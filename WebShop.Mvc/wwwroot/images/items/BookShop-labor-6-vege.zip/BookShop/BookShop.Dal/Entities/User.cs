﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;

namespace BookShop.Dal.Entities
{
    public class User : IdentityUser<int>
    {
        public string Name { get; set; }
        public ICollection<Comment> Comments { get; set; }
        public ICollection<Rating> Ratings { get; set; }
        public ICollection<Order> Orders { get; set; }
    }
}
