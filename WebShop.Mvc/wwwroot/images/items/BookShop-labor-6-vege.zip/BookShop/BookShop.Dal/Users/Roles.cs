﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Dal.Users
{
    public class Roles
    {
        public const string Administrators = nameof(Administrators);
    }
}
