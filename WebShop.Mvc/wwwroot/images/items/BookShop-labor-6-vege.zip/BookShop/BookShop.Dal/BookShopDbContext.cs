﻿using BookShop.Dal.Entities;
using BookShop.Dal.EntityConfigurations;
using BookShop.Dal.SeedInterfaces;
using BookShop.Dal.SeedService;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Dal
{
    public class BookShopDbContext : IdentityDbContext<User, IdentityRole<int>, int>
    {
        private readonly ISeedService _seedService;

        public BookShopDbContext( DbContextOptions options, ISeedService seedService ) : base( options )
        {
            _seedService = seedService;
        }

        // Adatbázis táblák
        public DbSet<Author> Authors { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Comment> Comments { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<Publisher> Publishers { get; set; }
        public DbSet<Rating> Ratings { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>().ToTable("Users");

            // Egy user 1x értékelhet 1 könyvet.
            modelBuilder.Entity<Rating>().HasAlternateKey(
                r => new { r.BookId, r.UserId });

            modelBuilder.Entity<Order>(e =>
           {
               e.OwnsOne(o => o.BillingAddress);
               e.OwnsOne(o => o.ShippingAddress);
           });

            modelBuilder.ApplyConfiguration(new AuthorEntityConfiguration(_seedService));
            modelBuilder.ApplyConfiguration(new BookEntityConfiguration(_seedService));
            modelBuilder.ApplyConfiguration(new CategoryEntityConfiguration(_seedService));
            modelBuilder.ApplyConfiguration(new PublisherEntityConfiguration(_seedService));
        }
    }
}
