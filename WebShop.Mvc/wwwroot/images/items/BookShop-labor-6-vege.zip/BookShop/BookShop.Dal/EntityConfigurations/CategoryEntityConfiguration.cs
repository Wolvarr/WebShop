﻿using BookShop.Dal.Entities;
using BookShop.Dal.SeedInterfaces;
using BookShop.Dal.SeedService;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Dal.EntityConfigurations
{
    public class CategoryEntityConfiguration : IEntityTypeConfiguration<Category>
    {
        private readonly ISeedService _seedService;

        public CategoryEntityConfiguration( ISeedService seedService)
        {
            _seedService = seedService;
        }

        public void Configure(EntityTypeBuilder<Category> builder)
        {
            builder.HasData(_seedService.Categories.Values);
        }
    }
}
