﻿using BookShop.Dal.Entities;
using BookShop.Dal.SeedInterfaces;
using BookShop.Dal.SeedService;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Dal.EntityConfigurations
{
    public class PublisherEntityConfiguration : IEntityTypeConfiguration<Publisher>
    {
        private readonly ISeedService _seedService;

        public PublisherEntityConfiguration( ISeedService seedService)
        {
            _seedService = seedService;
        }

        public void Configure(EntityTypeBuilder<Publisher> builder)
        {
            builder.HasData(_seedService.Publishers.Values);
        }
    }
}
