﻿using BookShop.Dal.Entities;
using BookShop.Dal.SeedInterfaces;
using BookShop.Dal.SeedService;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Dal.EntityConfigurations
{
    public class AuthorEntityConfiguration : IEntityTypeConfiguration<Author>
    {
        private readonly ISeedService _seedService;

        public AuthorEntityConfiguration( ISeedService seedService)
        {
            _seedService = seedService;
        }

        public void Configure(EntityTypeBuilder<Author> builder)
        {
            builder.HasData(_seedService.Authors.Values);
        }
    }
}
