﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Dal.Dto
{
    public class CommentHeader
    {
        public int Id { get; set; }
        public string User { get; set; }
        public int UserId { get; set; }
        public string Text { get; set; }
        public DateTimeOffset CreationDate { get; set; }
        public int BookId { get; set; }
    }
}
