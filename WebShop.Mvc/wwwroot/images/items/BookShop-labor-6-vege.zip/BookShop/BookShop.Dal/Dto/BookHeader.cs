﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Dal.Dto
{
    public class BookHeader
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Headline { get; set; }
        public string ShortDescription { get; set; }
        public decimal Price { get; set; }
        public decimal? DiscountedPrice { get; set; }
        public int PublishYear { get; set; }
        public int NumberOfPages { get; set; }
        public int? AuthorId { get; set; }
        public string Author { get; set; }
        public int PublisherId { get; set; }
        public string Publisher { get; set; }
        public int CategoryId { get; set; }
        public int NumberOfComments { get; set; }
        public int NumberOfRatings { get; set; }
        public double? AverageRating { get; set; }
    }
}
